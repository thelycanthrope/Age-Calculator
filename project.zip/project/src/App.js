import AgeCalci from './AgeCalci';
import AgeCalculator from './AgeCalculator';
import './App.css';

function App() {
  return (
    <div className="App">
      
     {/* <AgeCalci/> */}
     <AgeCalculator/>
    </div>
  );
}

export default App;
